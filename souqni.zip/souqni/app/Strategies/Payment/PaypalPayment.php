<?php

namespace App\Strategies\Payment;

class PaypalPayment implements PaymentStrategy {
    
    public function pay(float $amount): string {
        // منطق الدفع عبر بايبال
        return "Paid $amount using PayPal.";
    }
}
