<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PaymentController;


Route::get('/', function () {
    return view('login');
});

Route::get('/login', function () {
    return view('login');
});
    
Route::get('/register', function () {
    return view('register');
});

Route::get('/resetpassword', function () {
    return view('resetpassword');
});

Route::get('/home', function () {
    return view('home');
});

Route::get('/payment', function () {
    return view('payment');
});





Route::post('/home', function () {return view('home');});

Route::post('/register', [UserController::class, 'register']);

Route::post('/payment', [PaymentController::class, 'pay']);

// Route::post('/resetpassword', [UserController::class, 'adminResetPassword']);

// Route::post('/welcome_page', [UserController::class, 'login']);

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';