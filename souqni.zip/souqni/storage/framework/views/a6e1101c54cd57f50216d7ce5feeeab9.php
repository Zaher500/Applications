<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>الواجهة الرئيسية</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      text-align: center;
      padding-top: 100px;
    }
    h1 {
      margin-bottom: 30px;
    }
    button {
      padding: 12px 24px;
      font-size: 18px;
      background-color: #2980b9;
      color: white;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button:hover {
      background-color: #1c5981;
    }
  </style>
</head>
<body>

  <h1>Welcome!</h1>
  <button onclick="window.location.href='\payment'">Go to payment page</button>
  
<?php if(auth()->check()): ?>
    <p>رقم المستخدم: <?php echo e(auth()->user()->id); ?></p>
<?php else: ?>
    <p>لم يتم تسجيل الدخول</p>
<?php endif; ?>

</body>
</html>
<?php /**PATH C:\Users\LENOVO\Downloads\XAMPP\XAMPP\htdocs\laravel\souqni\resources\views/home.blade.php ENDPATH**/ ?>