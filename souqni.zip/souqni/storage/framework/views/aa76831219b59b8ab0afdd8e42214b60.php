
<?php /**PATH C:\Users\LENOVO\Downloads\XAMPP\XAMPP\htdocs\laravel\souqni\resources\views/auth/register.blade.php ENDPATH**/ ?>