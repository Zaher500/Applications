<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>صفحة الدفع</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 100px;
    }
    h2 {
      margin-bottom: 20px;
    }
    input[type="number"] {
      padding: 10px;
      font-size: 16px;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 20px;
      width: 200px;
      text-align: center;
    }
    .buttons {
      display: flex;
      gap: 20px;
    }
    button {
      padding: 10px 20px;
      font-size: 16px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    .card {
      background-color: #2ecc71;
      color: rgb(0, 0, 0);
    }
    .paypal {
      background-color: #f1c40f;
      color: black;
    }
    .return_to_home{
        background-color: #000b71;
        color: rgb(255, 255, 255);
    }
    button:hover {
      opacity: 0.85;
    }
  </style>
  
</head>
<body>

  <h2>Choose payment method</h2>

<form action="/payment" method="POST">
    <?php echo csrf_field(); ?>
    <input type="number" name="user_id" placeholder="Enter your user ID" required>
    <input type="number" name="amount" placeholder="Insert the amount" required>
    <input type="hidden" name="method" value="1">
    <button type="submit" class="card">Pay with Credit Card</button>
</form>

<form action="/payment" method="POST">
    <?php echo csrf_field(); ?>
    <input type="number" name="user_id" placeholder="Enter your user ID" required>
    <input type="number" name="amount" placeholder="Insert the amount" required>
    <input type="hidden" name="method" value="2">
    <button type="submit" class="paypal">Pay with PayPal</button>
</form>

<br>
<button class="return_to_home" onclick="window.location.href='/home'">Return to Home Page</button>

 
  

  

</body>
</html>
<?php /**PATH C:\Users\LENOVO\Downloads\XAMPP\XAMPP\htdocs\laravel\souqni\resources\views/payment.blade.php ENDPATH**/ ?>